# Multilanguage Plugin — Installation Guide

**Version:** 1.0.0 | **Author:** ATech

Full multilanguage routing, language switcher, and translation status manager for Payload CMS 3.x + Next.js App Router. Supports any number of locales configured in `payload.config.ts`. Activates or deactivates from the admin panel without code changes.

## What this plugin includes

| Feature | Route / Location |
|---|---|
| Language Settings global | `language-settings` global — active locales, default locale, auto-detect, switcher position, hreflang |
| Locale routing middleware | Updated `src/middleware.ts` — detects locale from cookie or Accept-Language, redirects/rewrites |
| Language Switcher dropdown | `src/components/LanguageSwitcher.tsx` — client component, sets `NEXT_LOCALE` cookie |
| `[locale]` layout | `src/app/(frontend)/[locale]/layout.tsx` — reads locale from params, injects `<html lang>` and hreflang tags |
| Language Settings API | `GET /api/plugins/multilanguage/settings` |
| Translation Status API | `GET /api/plugins/multilanguage/translation-status` |
| Translation Manager admin view | `/admin/plugins/multilanguage` — ✅/⚠️/❌ per collection/locale |

---

## Step 1 — Configure locales in `payload.config.ts`

The plugin uses whatever locales are declared in your Payload config. You must define them here first:

```ts
export default buildConfig({
  localization: {
    locales: [
      { label: 'English', code: 'en' },
      { label: 'Indonesian', code: 'id' },
      // Add more locales here
    ],
    defaultLocale: 'en',
    fallback: true,   // fall back to default locale when a translation is missing
  },
})
```

---

## Step 2 — Copy plugin files

```
src/
├── plugins/
│   ├── multilanguagePlugin.ts                      ← main plugin entry
│   └── multilanguage/
│       ├── LanguageSettingsGlobal.ts                ← Payload global for all settings
│       ├── TranslationManagerView.tsx               ← admin translation status component
│       └── seed.ts                                  ← seeds plugin + default settings
├── components/
│   └── LanguageSwitcher.tsx                         ← dropdown locale switcher (client)
├── app/
│   ├── api/
│   │   └── plugins/
│   │       └── multilanguage/
│   │           ├── settings/route.ts                ← GET language settings (public)
│   │           └── translation-status/route.ts      ← GET translation completeness data
│   └── (payload)/
│       └── admin/
│           └── plugins/
│               └── multilanguage/
│                   ├── layout.tsx                   ← Translation Manager page shell
│                   └── page.tsx                     ← Translation Manager admin page
├── migrations/
│   └── 20260521_060000_multilanguage_locale_fields.ts  ← adds language_settings tables
└── middleware.ts                                    ← updated — locale detection + routing
```

---

## Step 3 — Update `src/middleware.ts`

The locale routing block must be added to your existing middleware. The key logic:

```ts
const SUPPORTED_LOCALES = ['en', 'id']  // ← add your locales here

// In the middleware function, after admin/API pass-through:
if (!pathname.startsWith('/maintenance') && !pathname.match(/\.[^/]+$/)) {
  const firstSegment = pathname.split('/').filter(Boolean)[0] ?? ''
  if (!SUPPORTED_LOCALES.includes(firstSegment)) {
    const localeConfig = await getLocaleConfig(request)  // fetches /api/plugins/multilanguage/settings
    if (localeConfig.isActive) {
      let locale = localeConfig.defaultLocale ?? 'en'
      const cookieLocale = request.cookies.get('NEXT_LOCALE')?.value
      if (cookieLocale && SUPPORTED_LOCALES.includes(cookieLocale)) {
        locale = cookieLocale
      } else if (localeConfig.autoDetect) {
        const acceptLang = request.headers.get('accept-language') ?? ''
        const preferred = acceptLang.split(',')
          .map((l) => l.split(';')[0]?.trim().slice(0, 2).toLowerCase())
          .find((c) => c && SUPPORTED_LOCALES.includes(c))
        if (preferred) locale = preferred
      }
      const localePath = pathname === '/' ? '' : pathname
      const redirectUrl = new URL(`/${locale}${localePath}`, request.url)
      redirectUrl.search = request.nextUrl.search
      return NextResponse.redirect(redirectUrl, 307)
    } else {
      const rewriteUrl = new URL(`/en${pathname}`, request.url)
      rewriteUrl.search = request.nextUrl.search
      return NextResponse.rewrite(rewriteUrl)
    }
  }
}
```

> **Critical**: use `request.nextUrl.origin` when fetching `getLocaleConfig` — never hardcode `NEXT_PUBLIC_SITE_URL` in middleware, as it will resolve to the wrong host in some environments.

> **Critical**: use `cache: 'no-store'` in the `getLocaleConfig` fetch to avoid stale cached responses.

---

## Step 4 — Register the plugin in `payload.config.ts`

```ts
import { multilanguagePlugin } from './plugins/multilanguagePlugin'

export default buildConfig({
  plugins: [
    multilanguagePlugin(),
  ],
})
```

---

## Step 5 — Set up the `[locale]` frontend routes

Your frontend pages must be inside `src/app/(frontend)/[locale]/`. The locale layout reads `params.locale` and passes it to all data fetching functions:

```tsx
// src/app/(frontend)/[locale]/layout.tsx
export default async function LocaleLayout({ children, params }) {
  const { locale } = await params
  // fetch language settings, header, footer passing locale
  return (
    <html lang={locale}>
      <body>
        <Header locale={locale} />
        {children}
      </body>
    </html>
  )
}
```

The outer `(frontend)/layout.tsx` should be a passthrough:

```tsx
export default function FrontendGroupLayout({ children }) {
  return <>{children}</>
}
```

---

## Step 6 — Wire the Language Switcher into the Header

```tsx
// In your Header server component:
import { LanguageSwitcher } from '@/components/LanguageSwitcher'
import { getLanguageSettings } from '@/lib/payload'

export default async function Header({ locale }: { locale: string }) {
  const langSettings = await getLanguageSettings()
  const activeLocales = langSettings?.activeLocales?.filter(l => l.enabled) ?? []

  return (
    <header>
      <nav>...</nav>
      {langSettings?.showSwitcher && activeLocales.length > 1 && (
        <LanguageSwitcher activeLocales={activeLocales} currentLocale={locale} />
      )}
    </header>
  )
}
```

---

## Step 7 — Update `lib/payload.ts` data fetching functions

All data fetching functions need a `locale` parameter so they query the correct translation:

```ts
export async function getPage(slug: string, locale: string = 'en') {
  return payload.find({
    collection: 'pages',
    where: { slug: { equals: slug } },
    locale,
    limit: 1,
  })
}
```

Repeat for `getNavigation`, `getSettings`, `getTheme`, `getPostItem`, `getPortfolioItem`, etc. Update cache keys to include locale to prevent cross-locale cache pollution:

```ts
unstable_cache(fn, ['navigation', locale], { tags: ['navigation', locale] })
```

---

## Step 8 — Add `localized: true` to fields you want translated

In any Payload collection or global, mark fields as translatable:

```ts
// src/collections/Navigation.ts
{
  name: 'label',
  type: 'text',
  localized: true,   // ← this field gets a value per locale
}
```

---

## Step 9 — Run database migration

```bash
npm run migrate
```

This creates `language_settings` and `language_settings_active_locales` tables and any `_locales` tables for fields marked `localized: true`.

---

## Step 10 — Verify

1. Start the dev server: `npm run dev`
2. Visit `/` — should redirect to `/en` (307)
3. Visit `/id/` — should show Indonesian content (English fallback where not translated)
4. Click a locale in the Language Switcher — path changes, `NEXT_LOCALE` cookie is set
5. Refresh — stays on the selected locale
6. In Payload admin → **System** → **Language Settings** → disable the plugin → visit `/` — no redirect, widget hidden
7. Visit `/admin/plugins/multilanguage` — Translation Manager shows all collections with status

---

## Adding new languages later

1. Add the locale to `payload.config.ts → localization.locales`
2. Add it to `SUPPORTED_LOCALES` in `src/middleware.ts`
3. Run `npm run migrate:create && npm run migrate`
4. In Payload admin → Language Settings → Active Locales → add the new entry and enable it
5. Language Switcher and middleware pick it up automatically — no further code changes needed

---

## Reusability

- **Supported locales list**: keep `SUPPORTED_LOCALES` in `middleware.ts` in sync with `payload.config.ts`
- **Switcher position**: configure via Language Settings → Switcher Position (header/footer)
- **Auto-detect**: toggle via Language Settings → Auto-detect from Browser
- **hreflang tags**: toggle via Language Settings → Inject hreflang Tags
- **Translation Manager**: accessible at `/admin/plugins/multilanguage` — shows ✅/⚠️/❌ per collection + locale

---

## File reference

| File | Purpose |
|---|---|
| `multilanguagePlugin.ts` | Plugin factory — registers LanguageSettings global, runs seed |
| `multilanguage/LanguageSettingsGlobal.ts` | Payload global: active locales, default locale, auto-detect, switcher, hreflang |
| `multilanguage/TranslationManagerView.tsx` | Admin component showing translation status per collection/locale |
| `multilanguage/seed.ts` | Seeds plugin record + default settings on first start |
| `LanguageSwitcher.tsx` | Dropdown client component — switches locale, sets `NEXT_LOCALE` cookie |
| `api/multilanguage/settings/route.ts` | Returns `{ isActive, autoDetect, defaultLocale, activeLocales }` |
| `api/multilanguage/translation-status/route.ts` | Returns `{ total, translated }` per collection/locale |
| `migrations/20260521_060000_multilanguage_locale_fields.ts` | DB migration for `language_settings` tables |
